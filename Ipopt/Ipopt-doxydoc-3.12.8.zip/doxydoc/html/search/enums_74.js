var searchData=
[
  ['trialstatus',['TrialStatus',['../classIpopt_1_1PDPerturbationHandler.html#aeba46dcffb42bef16860cbb40c2a77f1',1,'Ipopt::PDPerturbationHandler::TrialStatus()'],['../classIpopt_1_1CGPerturbationHandler.html#aefa3d836643d40acba62f7b7e10dac56',1,'Ipopt::CGPerturbationHandler::TrialStatus()']]]
];
