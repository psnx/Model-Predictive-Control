var searchData=
[
  ['number',['Number',['../namespaceIpopt.html#ad77ec4132352c5093febf9c488a72a4c',1,'Ipopt::Number()'],['../IpStdCInterface_8h.html#a288a17d7858455cb06f6bce13912c92c',1,'Number():&#160;IpStdCInterface.h']]],
  ['numericmetadatamaptype',['NumericMetaDataMapType',['../classIpopt_1_1TNLP.html#aa3361681015593a2f7433036d761ae75',1,'Ipopt::TNLP::NumericMetaDataMapType()'],['../namespaceIpopt.html#a08458195ba30ac6f9e88a2a48c87df52',1,'Ipopt::NumericMetaDataMapType()']]]
];
