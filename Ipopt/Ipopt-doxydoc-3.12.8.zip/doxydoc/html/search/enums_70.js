var searchData=
[
  ['pardisomatchingstrategy',['PardisoMatchingStrategy',['../classIpopt_1_1IterativePardisoSolverInterface.html#a51ed4b3910167788c69e77aeb5044ccc',1,'Ipopt::IterativePardisoSolverInterface::PardisoMatchingStrategy()'],['../classIpopt_1_1PardisoSolverInterface.html#ac8001cd1faad8199ecfad60c0cd25daa',1,'Ipopt::PardisoSolverInterface::PardisoMatchingStrategy()']]]
];
