var searchData=
[
  ['journal',['Journal',['../classIpopt_1_1Journal.html',1,'Ipopt']]],
  ['journalist',['Journalist',['../classIpopt_1_1Journalist.html',1,'Ipopt']]]
];
