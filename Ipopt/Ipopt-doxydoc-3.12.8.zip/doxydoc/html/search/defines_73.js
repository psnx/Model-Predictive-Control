var searchData=
[
  ['sharedlibext',['SHAREDLIBEXT',['../MSVisualStudio_2v8-ifort_2IpOpt_2config_8h.html#afa98b3a0295460d28397b37270c930e7',1,'SHAREDLIBEXT():&#160;config.h'],['../src_2Common_2config_8h.html#afa98b3a0295460d28397b37270c930e7',1,'SHAREDLIBEXT():&#160;config.h']]],
  ['sizeof_5fint_5fp',['SIZEOF_INT_P',['../src_2Common_2config_8h.html#a53abd63f8f97b0a59e67832e1bdd33c5',1,'config.h']]],
  ['stdc_5fheaders',['STDC_HEADERS',['../src_2Common_2config_8h.html#a550e5c272cc3cf3814651721167dcd23',1,'config.h']]]
];
