var searchData=
[
  ['subject',['Subject',['../classIpopt_1_1Observer.html#a5daa6be80b3fbc385ac0a0d93ad161d9',1,'Ipopt::Observer']]],
  ['symtmatrix',['SymTMatrix',['../classIpopt_1_1SymTMatrixSpace.html#ab9f37d14cc9cc83a9e6c2b38dfb26355',1,'Ipopt::SymTMatrixSpace']]]
];
