var searchData=
[
  ['unassigned',['UNASSIGNED',['../namespaceIpopt.html#a53a5dc5f64f568252ba7bb7385e7f834a5d030c73470d1e8cabe27e481c9a58d0',1,'Ipopt']]],
  ['unrecoverable_5fexception',['Unrecoverable_Exception',['../namespaceIpopt.html#aefa0497854479cde8b0994cdf132c982abfb32ba9b5a198b8fa10d0e3b29ec68e',1,'Ipopt::Unrecoverable_Exception()'],['../IpReturnCodes__inc_8h.html#ab542e0b1ca364a9b7525a876ffdae7d7a77a7456dabd944cce710ce7266cf5f68',1,'Unrecoverable_Exception():&#160;IpReturnCodes_inc.h']]],
  ['user_5frequested_5fstop',['USER_REQUESTED_STOP',['../namespaceIpopt.html#a53a5dc5f64f568252ba7bb7385e7f834a22eecf4996da7cc0d36cdc47c83d6320',1,'Ipopt::USER_REQUESTED_STOP()'],['../namespaceIpopt.html#aefa0497854479cde8b0994cdf132c982aa5a336d22d2bed01da6e5ec8e2d4d4a1',1,'Ipopt::User_Requested_Stop()'],['../IpReturnCodes__inc_8h.html#ab542e0b1ca364a9b7525a876ffdae7d7adc86c05bff28bad8f7aac1c137a3f41b',1,'User_Requested_Stop():&#160;IpReturnCodes_inc.h']]],
  ['user_5fstop',['USER_STOP',['../classIpopt_1_1ConvergenceCheck.html#a0c6c029f369b9529443d945db60c6a98ab42f85acd14df65771faa300210b8cb9',1,'Ipopt::ConvergenceCheck']]]
];
