var searchData=
[
  ['ampltnlp',['AmplTNLP',['../classIpopt_1_1AmplSuffixHandler.html#afcd2fd0b07735db08932918ecb49ea95',1,'Ipopt::AmplSuffixHandler']]]
];
