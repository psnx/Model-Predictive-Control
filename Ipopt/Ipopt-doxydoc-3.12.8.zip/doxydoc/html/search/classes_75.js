var searchData=
[
  ['userscaling',['UserScaling',['../classIpopt_1_1UserScaling.html',1,'Ipopt']]]
];
