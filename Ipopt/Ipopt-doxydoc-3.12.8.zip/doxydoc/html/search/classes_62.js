var searchData=
[
  ['backtrackinglinesearch',['BacktrackingLineSearch',['../classIpopt_1_1BacktrackingLineSearch.html',1,'Ipopt']]],
  ['backtrackinglsacceptor',['BacktrackingLSAcceptor',['../classIpopt_1_1BacktrackingLSAcceptor.html',1,'Ipopt']]]
];
