var searchData=
[
  ['sohandle_5ft',['soHandle_t',['../LibraryHandler_8h.html#aedf51f406398749313f0212b5bbfc766',1,'LibraryHandler.h']]],
  ['stringmetadatamaptype',['StringMetaDataMapType',['../classIpopt_1_1TNLP.html#ac30bc524e7fb8ff836bd6657c8fce004',1,'Ipopt::TNLP::StringMetaDataMapType()'],['../namespaceIpopt.html#a93d1b2b94faf16ee2c06be07b74c2869',1,'Ipopt::StringMetaDataMapType()']]]
];
